const CONFIG = {
    titleWeb: "Tiêu đề web",
    introTitle: 'Hello',
    introDesc: `Anh có chuyện muốn nói với em , Nhớ trả lời thật lòng nhá :>`,
    btnIntro: '^Oke^',
    title: 'Làm người yêu anh nhé :3',
    desc: 'Nếu em không trả lời hoặc thoát tức là em đồng ý rồi nhá',
    btnYes: 'Đồng ý <33',
    btnNo: 'Không nha :3',
    question: 'Nói cho anh lý do vì sao em yêu anh đii <3',
    btnReply: 'Gửi cho bạn <3',
    reply: 'Yêu thì yêu mà không yêu thì yêu <33333333',
    mess: 'anh biết mà 🥰. Yêu em nhiều nhiều 😘😘',
    messDesc: 'Ib cho anh ngay nhá <3',
    btnAccept: 'Okiiiii lun <3',
    messLink: 'https://github.com/chinh096/thangut0906.git'
}